#!/usr/bin/python

# libraries

import os
import sys
import subprocess
import getopt

# vars

# strings $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
currRecipiant = ""
currFile = ""
currFolder = ""
currUser = ""
configFileName = "/usr/lib/0ddPGP/0dd3yePGP-Config"
backupName = "/usr/lib/0ddPGP/configBackup"
cronLogFileName = '/usr/lib/0ddPGP/cronTasksLog'
cronConfigFolderName = '/usr/lib/0ddPGP/cron/cron-configs'
cronScriptFileName = '/usr/lib/0ddPGP/baseCronScript.sh'
executeFileName = '/usr/lib/0ddPGP/cron/cron-scripts/ExecuteCronTasks.sh'

# lists $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
configOptions = []
allOption = ['Print Current Options', 'Exit Program', 'Change Default Recipiant', 'Change Default File', 'Change Default Folder', 'Clear Config Options', 'Encrypt Single File', 'Decrypt Single File', 'Encrypt Folder Using Tar', 'Decrypt Encrypted Tar', 'Encrypt Folder Contents', 'Decrypt Folder Contents', 'Toggle Should Clean', 'Create Cron Task', 'Print Cron Tasks', 'Remove Cron Task', 'Enable Cron Tasks', 'Disable Cron Tasks', 'Transfer Public Key To Other User']
currFileList = []
encryptedList = []
decryptedList = []
folderList = []
validRecipiantList = []

# dictionaries $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
settingsChecker = {"-e":"rfs","-d":"fs","-E":"rFs","-D":"fs","-c":"rFs","-C":"Fs"}

# $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# methods

# Interface Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#options interface
def mainInterface():

	options = ['Print Current Options', 'Change Default Recipiant', 'Change Default File', 'Change Default Folder', 'Toggle Should Clean', 'Clear Config Options', 'Print Cron Tasks', 'Create Cron Task', 'Remove Cron Task', 'Enable Cron Tasks', 'Disable Cron Tasks', 'Transfer Public Key To Other User', 'Encrypt Single File', 'Decrypt Single File', 'Encrypt Folder Using Tar', 'Decrypt Encrypted Tar', 'Encrypt Folder Contents', 'Decrypt Folder Contents', 'Exit Program']

	executeCommand("clear", 0)

	print "\nConfiguration Options:"
	for x in range(0,6):
		print str(x) + ": " + options[x]
	
	print "\nCron Options:"
	for x in range(6,12):
		print str(x) + ": " + options[x]
	
	print "\nEncryption Options:"
	for x in range(12,18):
		print str(x) + ": " + options[x]
	
	print "\n" + str(len(options)-1) + ": " + options[len(options)-1] + "\n"


	# Warns user for not being root
	if isRoot() != 1:
		print "\nWarning: User is not root"

	output = raw_input('\nEnter number corresponding to option: ')
	
	try:
	
		output = int(output)
		if output > -1 and output < 20:
			print "\nYou chose " + str(output) + "\n"
			interfaceOptionSelecter(options[output])
	except ValueError:
		
		print "Error: Option must be number"
		waitForUserInput()
		mainInterface()

# pretty self explanatory. Acts as wait after option is selected
def waitForUserInput():
	tempVar = raw_input("Press Enter to Continue: ")



# takes a list and then prints contents as if they were options in an interface
def printOptionList(optionList, headerStr):
	print headerStr
	for x in range (0, len(optionList)):
		print str(x+1) + ": " + optionList[x]
	

# typically used after user is prompted to make a choice between indexes in a list. Makes sure their choice is valid and then returns it
def getUserChoiceFromOptionList(optionList, promptStr):
	choice = -1
	choice = int(raw_input('\n' + promptStr))-1

	while choice == -1 or choice > len(optionList)-1:
			print "\nError: Choice Out Of Bounds. Please Enter Valid Option:"	
			choice = int(raw_input('\n' + promptStr))-1
	return choice	




# checks if user is root and kills program if not
def killIfNotRoot():
	if isRoot() != 1:
		print "\nError: User must be root to do that."
		exitProgram()



# method to tie things together for the interface and switch case
def interfaceOptionSelecter(selected):
	index = strOptionToArrayIndex(selected)
	switchCaseOptions(index)

	
# basic switch case cuz python is not java
def switchCaseOptions(argument):
	switcher = {
	0: printConfigOptions,
	1: exitProgram,
	2: changeRecipiantOption,
	3: changeFileOption,
	4: changeFolderOption,
	5: clearAllOptions,
	6: encryptSingleProc,
	7: decryptSingleProc,
	8: encryptFolderProc,
	9: decryptFolderProc,
	10: encryptFolderContentsProc,
	11: decryptFolderContentsProc,
	12: changeShouldClean,
	13: createCronTaskInterface,
	14: printCronTasks,
	15: removeCronTaskInterface,
	16: enableCronTasks,
	17: disableCronTasks,
	18: transferKeyInterface
	
	}
	
	func = switcher.get(argument, lambda: "Invalid")
	print func()


# takes option selected in form of string and returns valid index in form of int. Return -1 if no option exists triggering an error
def strOptionToArrayIndex(strOption):
	for x in range(0, len(allOption)):
		if strOption == allOption[x]:
			return x
	return -1		

# interface for creating cron tasks using program
def createCronTaskInterface():
	# var declaration
	global settingsChecker
	recArg = ""
	fileArg = ""
	folderArg = ""
	shouldCleanArg = -1
	schedule = ""

	# makes sure user is root
	killIfNotRoot()

	# gens name of task
	nameString = genCronConfigFileName()

	# gets schedule for task
	schedule = selectCronScheduleInterface()
	setCronExecuteFileName(schedule)

	# gets type of task
	taskType = taskTypeSelectionInterface()
	checkStr = settingsChecker[genCommandLineArg(taskType)]
	print "\nTask type set to " + taskType + "\n"

	# whiles make sure input is valid and required
	recArg = cronTaskSetRecipiantIfNeeded(taskType, checkStr)
	fileArg = cronTaskSetFileIfNeeded(taskType, checkStr)
	folderArg = cronTaskSetFolderIfNeeded(taskType, checkStr)
	shouldCleanArg = cronTaskSetShouldCleanIfNeeded(taskType, checkStr)

	# actually makes file
	genCronConfigFile(recArg, fileArg, folderArg, shouldCleanArg, nameString)
	
	# add reference of cron task to log
	addCronTaskReferenceToLog(nameString, taskType, schedule)
	
	# gens command for use in actual cron task and then adds it to execute script
	addTaskToScript(genCronScriptCommand(nameString, taskType))
	
	waitForUserInput()
	mainInterface()


# prints a list of options and prompts user to select one and then returns their selection
def getItemFromUserInterface(optionList, promptStr):	
	choice = -1

	printOptionList(optionList, '\nOptions:\t\n')
	choice = getUserChoiceFromOptionList(optionList, promptStr)
	
	return optionList[choice]	

# if task requires a recipiant, it gets one from the user. Otherwise it returns an empty string
def cronTaskSetRecipiantIfNeeded(taskType, checkStr):
	global validRecipiantList	
	recArg = ""
	
	if checkStr.count("r") > 0:
		recArg = getItemFromUserInterface(validRecipiantList, "\nSelect public key to use: ")	
	
	return recArg	


# if task requires a file, it gets one from the user. Otherwise it returns an empty string
def cronTaskSetFileIfNeeded(taskType, checkStr):
	fileArg = ""
	
	if checkStr.count("f") > 0:
		print "\n$: View options in current folder\n"
		fileArg = raw_input("Enter desired file for use in cron task: ")
		
		if fileArg == "$":
			fileArg = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(1,0), "\nSelect file to use: ").replace("\n", "")
	return fileArg	



# if task requires a folder, it gets one from the user. Otherwise it returns an empty string
def cronTaskSetFolderIfNeeded(taskType, checkStr):
	folderArg = ""
	
	if checkStr.count("F") > 0:
		print "\n$: View options in current folder\n"
		folderArg = raw_input("Enter desired folder for use in cron task: ")

		if folderArg == "$":
			folderArg = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(0,1), "\nSelect folder to use: ").replace("\n", "")
		
	return folderArg	

# if task requires a shouldClean, it gets one from the user. Otherwise it returns an empty string
def cronTaskSetShouldCleanIfNeeded(taskType, checkStr):
	shouldCleanArg = "2"
	
	if checkStr.count("s") > 0:
		shouldCleanArg = int(raw_input("Should task clean up files after done (0/1): "))
		while shouldCleanArg != 1 and shouldCleanArg != 0: 
			print "\nError: shouldClean has to be either 0 or 1. Please enter valid value: "
			shouldCleanArg = int(raw_input("Should task clean up files after done (0/1): "))	
	
	return shouldCleanArg	


# gets schedule for cron task
def selectCronScheduleInterface():
	options = ['@reboot', '@yearly', '@monthly', '@weekly', '@daily', '@hourly']
	return getItemFromUserInterface(options, "\nSelect schedule for task: ")	


# interface for selecting task type
def taskTypeSelectionInterface():
	options = ['Encrypt Single File', 'Encrypt Folder Using Tar', 'Encrypt Folder Contents']
	return getItemFromUserInterface(options, "\nSelect type of task to set cron: ")
	

# interface for transferring public key from one user to another
def transferKeyInterface():
	
	# makes sure user is root
	killIfNotRoot()

	# var declaration
	userList = getUserList()
	choice = -1
	toUser = ""
	fromUser = ""
	keyToTransfer = ""
	tmpValidRecipiantList = []

	# gets user to take public key from
	printOptionList(userList, '\nUser Options:\t\n')

	choice = getUserChoiceFromOptionList(userList, '\nSelect user to get key from: ')

	print "\nYou chose to get public key from " + userList[choice] + "\n"
	fromUser = userList[choice]
	choice = -1

	# gets key to export
	tmpValidRecipiantList = parseRawGpgKeys(genRawGpgTextForUser(fromUser))

	if len(tmpValidRecipiantList) == 0:
		print "Error: " + fromUser + " does not have any keys for you to transfer."
		exitProgram()

	printOptionList(tmpValidRecipiantList, '\nKey Options:\t\n')
 
	choice = getUserChoiceFromOptionList(tmpValidRecipiantList, '\nSelect public key to transfer: ')
	
	print "\nYou chose to transfer " + tmpValidRecipiantList[choice] + "\n"
	keyToTransfer = tmpValidRecipiantList[choice]
	choice = -1

	# gets user to transfer public key to
	userList.remove(fromUser)
	printOptionList(userList, '\nUser Options:\t\n')

	choice = getUserChoiceFromOptionList(userList, '\nSelect user to transfer key to: ')
	
	print "\nYou chose to transfer public key to " + userList[choice] + "\n"
	toUser = userList[choice]
	choice = -1

	# actually does the thing
	transferKey(fromUser, toUser, keyToTransfer)

	waitForUserInput()
	mainInterface()



# gets current options set in config file and prints them to terminal
def printConfigOptions():
	global configOptions
	printOptionList(configOptions, '\nConfig Options:\t\n')
	waitForUserInput()
	mainInterface()


# prints cron tasks set by program in past
def printCronTasks():
	# makes sure user is root
	killIfNotRoot()

	cronTasksList = listAllSetCronTasks()

	if len(cronTasksList) == 0:
		print "\nNo cron tasks have been set yet.\n" 
	else:
		print "\nThere are " + str(len(cronTasksList)) + " tasks set.\n"#dfghj
		printOptionList(cronTasksList, '\nCron Tasks:\t\n')
	print "\nCheck the log file at /usr/lib/0ddPGP/cronTasksLog for more information.\n"

	waitForUserInput()
	mainInterface()


# interface for removing cron tasks created by program
def removeCronTaskInterface():
	# makes sure user is root
	killIfNotRoot()

	cronTasksList = listAllSetCronTasks()
	selection = ""	

	if len(cronTasksList) == 0:
		print "\nNo cron tasks have been set yet, so you can't remove any.\n" 
	else:
		print "\nThere are " + str(len(cronTasksList)) + " tasks set.\n"
		cronTasksList.append("Clear All")
		selection = getItemFromUserInterface(cronTasksList, "\nSelect Cron Task To Remove: ")
		cronTasksList.remove("Clear All")

		if selection == "Clear All":
			# removes all cron stuff
			for x in range(0, len(cronTasksList)):
				removeCronTask(cronTasksList[x])				
		else:
			# removes specified cron task
			removeCronTask(selection)

	waitForUserInput()
	mainInterface()



# removes targetFile if shouldCleanUp is set to 1
def removeFileIfShould(targetFile):
	global configOptions
	if configOptions[3][len(configOptions[3])-2] == "1":
		removeFile(targetFile)


# removes targetFolder if shouldCleanUp is set to 1
def removeFolderIfShould(targetFolder):
	global configOptions
	if configOptions[3][len(configOptions[3])-2] == "1":
		removeFolder(targetFolder)



# Config File Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# makes sure the default files in config file are indeed files
def verifyFileOptions():
	global configOptions
	if isFile(configOptions[1][5:len(configOptions[1])-1]) != 1:
		print "Error: " + configOptions[1][5:len(configOptions[1])-1] + " is not a valid file. Please enter valid file."
		exitProgram()

# makes sure the default folders in config file are indeed folders
def verifyFolderOptions():
	global configOptions
	if isFolder(configOptions[2][7:len(configOptions[2])-1]) != 1:
		print "Error: " + configOptions[2][7:len(configOptions[2])-1] + " is not a valid folder. Please enter valid folder."
		exitProgram()


# makes sure gpg recipiant exists
def verifyRecipiantOptions():
	global configOptions
	if isValidRecipiant(configOptions[0][10:len(configOptions[0])-1]) != 1:
		print "Error: " + configOptions[0][10:len(configOptions[0])-1] + " is not a valid recipiant. Please enter valid recipiant."
		exitProgram()

# makes sure shouldClean is either 1 or 0
def verifyShouldClean():
	global configOptions
	if configOptions[3][0:len(configOptions[3])-1] != "ShouldCleanUp:1" and configOptions[3][0:len(configOptions[3])-1] != "ShouldCleanUp:0":
		print "Error: " + configOptions[3][0:13] + " must be either 1 or 0. Please fix."
		exitProgram()



# sets the configOptions list for future use in program
def setConfigOptions():
	# due to usage of append() you should only use this method if the configOptions list is empty
	global configFileName
	global configOptions
	getCurrUser()
	tempConfigFile = open(configFileName, "r")
	configFileOptions = tempConfigFile.readlines()	
	
	for x in range(1, len(configFileOptions)-1):
		configOptions.append(configFileOptions[x])
	tempConfigFile.close()
	setValidRecipiants()


# sets valid recipiant list for verification purposes later. There is a little redundancy using this method, but whatever.
def setValidRecipiants():
	global validRecipiantList
	validRecipiantList = parseRawGpgKeys(genRawGpgText())
	

# changes recipiant option in config file
def changeRecipiantOption():
	# this method is kinda messy, but it works
	global configOptions
	global configFileName
	global validRecipiantList	

	# checks if there is already a default options set
	if len(configOptions[0]) == 11:	# 11 is the length of the string the option would be if it was not set
		print "There is currently no default recipiant\n"
	else:
		# removes option from file so that when new one is created, the old option will not remain
		print "The current default recipiant is " + configOptions[0][10:len(configOptions[0])] + "\n" 
		findAndReplaceText(configOptions[0][10:len(configOptions[0])], "\n", configFileName)
		
	# actually does the thing
	newOption = getItemFromUserInterface(validRecipiantList, "\nSelect public key to use: ")
	insertText("Recipiant:", newOption, configFileName)
	print "The default recipiant has been changed to " + newOption + "\n"
	# this is the weird part. You need to do this instead of using previous method so that the old var doesn't remain.
	configOptions[0] = "Recipiant:" + newOption + "\n"
	waitForUserInput()
	mainInterface()


# changes file option in config file
def changeFileOption():
	# this method is kinda messy, but it works
	global configOptions
	global configFileName
	
	# checks if there is already a default options set
	if len(configOptions[1]) == 6:	# 6 is the length of the string the option would be if it was not set
		print "There is currently no default file\n"
	else:
		# removes option from file so that when new one is created, the old option will not remain
		print "The current default file is " + configOptions[1][5:len(configOptions[1])] + "\n" 
		findAndReplaceText(configOptions[1][5:len(configOptions[1])], "\n", configFileName)
		
	# actually does the thing

	print "\n$: View options in current folder\n"
	newOption = raw_input("Enter the desired new default file: ")
	if newOption == "$":
		newOption = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(1,0), "\nSelect file to use: ").replace("\n", "")
	insertText("File:", newOption, configFileName)
	print "The default file has been changed to " + newOption + "\n"
	# this is the weird part. You need to do this instead of using previous method so that the old var doesn't remain.
	configOptions[1] = "File:" + newOption + "\n"
	waitForUserInput()
	mainInterface()

# changes folder option in config file
def changeFolderOption():
	# this method is kinda messy, but it works
	global configOptions
	global configFileName
	
	# checks if there is already a default options set
	if len(configOptions[2]) == 8:	# 8 is the length of the string the option would be if it was not set
		print "There is currently no default folder\n"
	else:
		# removes option from file so that when new one is created, the old option will not remain
		print "The current default folder is " + configOptions[2][7:len(configOptions[2])] + "\n" 
		findAndReplaceText(configOptions[2][7:len(configOptions[2])], "\n", configFileName)
		
	# actually does the thing
	print "\n$: View options in current folder\n"
	newOption = raw_input("Enter the desired new default folder: ")
	if newOption == "$":
		newOption = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(0,1), "\nSelect folder to use: ").replace("\n", "")
	insertText("Folder:", newOption, configFileName)
	print "The default folder has been changed to " + newOption + "\n"
	# this is the weird part. You need to do this instead of using previous method so that the old var doesn't remain.
	configOptions[2] = "Folder:" + newOption + "\n"
	waitForUserInput()
	mainInterface()


# changes shouldClean setting. Since it's a boolean option, it doensn't require user input to change
def changeShouldClean():
	global configOptions
	global configFileName

	print "Should Clean Up is currently set to " + str(configOptions[3][len(configOptions[3])-2]) + "\n" 
	
	if configOptions[3][len(configOptions[3])-2] == "1":
		findAndReplaceText("ShouldCleanUp:1", "ShouldCleanUp:0", configFileName)
		print "Should Clean Up has been changed to 0"
		configOptions[3] = "ShouldCleanUp:0\n"
	else:
		findAndReplaceText("ShouldCleanUp:0", "ShouldCleanUp:1", configFileName)
		print "Should Clean Up has been changed to 1\n"
		configOptions[3] = "ShouldCleanUp:1\n"
	waitForUserInput()
	mainInterface()
	

# clears the config file setting all vars to ""
def clearAllOptions():
	global configFileName
	global backupName
	global configOptions
	tempFile = open(backupName, "r")
	tempStr = tempFile.read()
	tempFile.close()
	tempFile = open(configFileName, "w")
	tempFile.write(tempStr)
	tempFile.close()
	reduceWhiteSpaceFile(1, configFileName)
	configOptions = []
	setConfigOptions()
	print "\nCleared all options in config file\n"
	waitForUserInput()
	mainInterface()


# Basic Var Manipulation Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# checks if item is in list
def isItemInList(checkItem, checkList):	

	if checkItem in checkList:	
		return 1
	else:
		return 0

# finds a string in a file, adds a string right after it 
def insertText(findStr, insertStr, filename):
	fileObj = open(filename, "r")
	tempStr = fileObj.read()
	fileObj.close()

	index = tempStr.find(findStr) + len(findStr)

	newStr = tempStr[0:index] + insertStr + tempStr[index:len(tempStr)]	

	fileObj = open(filename, "w")
	fileObj.write(newStr)
	fileObj.close()

	return newStr

# finds string in file and replaces it with specified string
def findAndReplaceText(findStr, insertStr, filename):
	
	fileObj = open(filename, "r")
	rawStr = fileObj.read()
	fileObj.close()
	rawStr = replaceTextInStr(rawStr, findStr, insertStr)
	fileObj = open(filename, "w")
	fileObj.write(rawStr)

	return rawStr

	
# sorts files into 2 lists for encrypted files and unencrypted each. If file is a dir it puts it into its own list
def sortFilesIntoLists():
	global encryptedList
	global decryptedList
	global folderList
	global currFileList
	global currFolder

	for x in range(0, len(currFileList)):

		if isFolder(currFolder + "/" + currFileList[x]) == 1:
			folderList.append(currFolder + "/" + currFileList[x])
		else:
			if isFileEncrypted(currFolder + "/" + currFileList[x]) == 1:
				encryptedList.append(currFolder + "/" + currFileList[x])
			else:
				decryptedList.append(currFolder + "/" + currFileList[x])		


# takes an int equal to the min amount of \n you want and the name of the target string. It then applies it
def reduceWhiteSpaceStr(minNewLines, rawStr):
	# var declaration	
	whiteSpaceStr = ""
	# generate str equal to minNewLines newlines
	for x in range(0, minNewLines):
		whiteSpaceStr += "\n"
	# runs replaceText method until there is no whiteSpace left other than whiteSpace less than min + 1
	while rawStr.count(whiteSpaceStr + "\n") > 0:
		rawStr = replaceTextInStr(rawStr, whiteSpaceStr + "\n", whiteSpaceStr)

	return rawStr

# basically a file version of reduceWhiteSpaceStr 
def reduceWhiteSpaceFile(minNewLines, fileName):
	fileObj = open(fileName, "r")
	newStr = reduceWhiteSpaceStr(minNewLines, fileObj.read()) 
	fileObj.close()
	fileObj = open(fileName, "w")
	fileObj.write(newStr)
	fileObj.close()

# Finds first instance of findStr and returns newStr which is equal to base with the first instace of findStr replaced with replaceStr
def replaceTextInStr(baseStr, findStr, replaceStr):
	# gets index of first instance of findStr	
	startIndex = baseStr.find(findStr)	
	# makes two strings: 1 is the baseStr truncated at the index of findStr and the second is everything in base after findStr
	half1 = baseStr[0:startIndex]
	half2 = baseStr[startIndex + len(findStr):len(baseStr)]
	# returns new str equal to half1 + replaceStr + half2
	return half1 + replaceStr + half2


# takes string idealy from genRawGpgText() output and parses through it looking for the names of valid public keys. Returns list with those keys 
def parseRawGpgKeys(rawText):
	potentialKeys = []
	checkStrings = '] '
	index = -1
	addStr = ""
	
	while rawText.count(checkStrings) > 0:
		index = rawText.find(checkStrings) + len(checkStrings)
		rawText = rawText[index:len(rawText)]
		index = rawText.find("\n")
		
		if index > rawText.find(" <"):
			index = rawText.find(" <")
		potentialKeys.append(rawText[0:index])

	return potentialKeys		


# adds command to execute script that will execute task. The execute script when in cron will then run and that's how the system works
def addTaskToScript(commandStr):
	global executeFileName
	fileObj = open(executeFileName, "a")
	fileObj.write(commandStr + "\n\n")
	fileObj.close()
	reduceWhiteSpaceFile(3,executeFileName)
	


# Encryption/Gpg Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# calls bash to encrypt using gpg
def encryptFile(filepath, recipiant):
	subprocess.call(["gpg", "-r", recipiant, "--armor","--output", filepath + ".asc", "--encrypt", filepath])
	removeFileIfShould(filepath)

# compresses folder to .tar.gz and then encrypts using gpg 
def encryptFolder(folderpath, recipiant):
	filename = folderpath[0:len(folderpath)]
	if folderpath.rfind("/") != -1:
		filename = folderpath[folderpath.rfind("/")+1:len(folderpath)]		
	executeCommand("mkdir " + folderpath + "/" + filename, 0)
	executeCommand("mv " + folderpath + "/* " + folderpath + "/" + filename, 0)
	executeCommand("tar czf " + folderpath + ".tar.gz -C " + folderpath + " .", 0)
	executeCommand("gpg -r" + recipiant + " --armor --output " + folderpath + ".asc --encrypt " + folderpath + ".tar.gz", 0)
	removeFileIfShould(folderpath + ".tar.gz")
	removeFolderIfShould(folderpath)


# calls bash to decrypt using gpg
def decryptFile(filepath):
	subprocess.call(["gpg", "--output", filepath[0:len(filepath)-4], "--decrypt", filepath])
	removeFileIfShould(filepath)


# decompresses folder to .tar.gz and then decrypts using gpg 
def decryptFolder(filepath):
	filename = filepath[0:len(filepath)-4]
	if filepath.rfind("/") != -1:
		filename = filepath[filepath.rfind("/")+1:len(filepath)-4]		

	subprocess.call(["gpg", "--output", filepath[0:len(filepath)-4] + ".tar.gz", "--decrypt", filepath])
	print filepath[0:len(filepath)-4] + ".tar.gz"
	subprocess.call(["tar", "xzf", filename + ".tar.gz"])
	removeFileIfShould(filepath)
	removeFileIfShould(filepath[0:len(filepath)-4] + ".tar.gz")

# returns true if file is encrypted
def isFileEncrypted(checkFile):
	tempFileObj = open(checkFile, "r")
	if tempFileObj.read(26) == "-----BEGIN PGP MESSAGE----":
		tempFileObj.close()
		return 1
	else:
		tempFileObj.close()
		return 0
	

# decrypts all files in encryptedList
def decryptAllInEncryptedList():
	global encryptedList
	
	for x in range(0, len(encryptedList)):
		decryptFile(encryptedList[x])
	print "Decrypted the following files:\n" + str(encryptedList)



# encrypts all files in decryptedList
def encryptAllInEncryptedList():
	global decryptedList
	global currRecipiant
	
	for x in range(0, len(decryptedList)):
		encryptFile(decryptedList[x], currRecipiant)
	print "Encrypted the following files:\n" + str(decryptedList)


# calls gpg --list-keys to get all potential public keys and then greps it to narrow things down. Returns string of grepped crap
def genRawGpgText():
	return executeCommand('gpg --list-keys | grep uid           ', 1)


# just like genRawGpgText, but executes it as specified user
def genRawGpgTextForUser(user):	
	if isUser(user) == 0:
		print "Error: Tried to execute command as a user that does not exist"
		exitProgram()
	return executeCommandAsUser(user, 'gpg --list-keys | grep uid           ', 1)


# if checkStr is a valid gpg recipiant, it returns a 1. Otherwise it returns 0
def isValidRecipiant(checkStr):
	global validRecipiantList	

	if checkStr in validRecipiantList:	
		return 1
	else:
		return 0

# transfers public key from one user to another
def transferKey(fromUser, toUser, keyName):
	fromUserKeys = parseRawGpgKeys(genRawGpgTextForUser(fromUser))
	toUserKeys = parseRawGpgKeys(genRawGpgTextForUser(toUser)) 

	# makes sure key is valid
	if isItemInList(keyName, fromUserKeys) == 0:
		print "Error: " + keyName + " is not a key in " + fromUser + "\'s keyring"
		exitProgram()

	exportKeyFileName = (executeCommandAsUser(fromUser, "eval echo ~" + fromUser, 1).replace("\n", "") + "/" +  keyName + ".pgp").replace(" ", "")

	# exports key
	
	executeCommandAsUser(fromUser, "gpg --output " + exportKeyFileName + " --armor --export " + keyName, 0)

	# makes sure proper users have permissions to import file 
	executeCommand("mv " + exportKeyFileName + " " + executeCommandAsUser(toUser, "eval echo ~", 1).replace("\n", "") + "/", 0)
	exportKeyFileName = (executeCommandAsUser(toUser, "eval echo ~" + toUser, 1).replace("\n", "") + "/" +  keyName + ".pgp").replace(" ", "")

	# imports key
	executeCommandAsUser(toUser, "gpg --import " + exportKeyFileName, 0)
	toUserKeys = parseRawGpgKeys(genRawGpgTextForUser(toUser)) 
	
	# cleans up
	executeCommandAsUser(toUser, "rm -f " + exportKeyFileName, 0)

	# makes sure key is valid
	if isItemInList(keyName, toUserKeys) == 0:
		print "Error: Key was not transferred successfully"
		exitProgram()




# Getters $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# gets current user and sets global var to it
def getCurrUser():
	global currUser	
	pipe = os.popen('whoami')
	currUser = pipe.read()
	

# var set through user input
def getRecipiantFromUser():
	global currRecipiant
	global configOptions
	global validRecipiantList

	if len(configOptions[0]) == 11:
		currRecipiant = getItemFromUserInterface(validRecipiantList, "\nSelect public key to use: ")
		configOptions[0] = "Recipiant:" + currRecipiant + "\n"
		print "Recipiant set to " + currRecipiant + "\n"
	else:
		currRecipiant = configOptions[0][10:len(configOptions[0])-1]
		print "There is already a default recipiant: " + configOptions[0][10:len(configOptions[0])]
	verifyRecipiantOptions()

# var set through user input
def getFilepathFromUser():
	global currFile
	global configOptions
	
	if len(configOptions[1]) == 6:
		print "\n$: View options in current folder\n"
		currFile = raw_input("Enter the desired file: ")
		if currFile == "$":
			currFile = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(1,0), "\nSelect file to use: ").replace("\n", "")
		configOptions[1] = "File:" + currFile + "\n"
		print "Filepath set to " + currFile + "\n"
	else:
		currFile = configOptions[1][5:len(configOptions[1])-1]
		print "There is already a default file: " + configOptions[1][5:len(configOptions[1])]
	verifyFileOptions()

# var set through user input
def getFolderpathFromUser():
	global currFolder
	global configOptions
 
	if len(configOptions[2]) == 8:
		print "\n$: View options in current folder\n"
		currFolder = raw_input("Enter the desired folder: ")
		if currFolder == "$":
			currFolder = executeCommand("pwd", 1).replace("\n", "") + "/" + getItemFromUserInterface(getLsList(0,1), "\nSelect folder to use: ").replace("\n", "")
		configOptions[2] = "Folder:" + currFolder + "\n"
		print "Folder set to " + currFolder + "\n"
	else:
		currFolder = configOptions[2][7:len(configOptions[2])-1]
		print "There is already a default folder: " + configOptions[2][7:len(configOptions[2])]
	verifyFolderOptions()
	


# gets folder contents and prints files to list
def getFileList(folderVar):
	global currFileList
	currFileList = os.listdir(folderVar)


# File Manipulation Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# returns 1 if provided string is name of accessible file and 0 if not
def isFile(checkFile):
	if os.path.isfile(checkFile):
		return 1
	else:
		return 0


# returns 1 if provided string is name of accessible folder and 0 if not
def isFolder(checkFolder):
	if os.path.isdir(checkFolder):
		return 1
	else:
		return 0


# removes targetFile. Will check if file exists and if it doesn't it will redirect to main interface
def removeFile(targetFile):	
	if isFile(targetFile) == 1:
		subprocess.call(["rm", targetFile])
	else:
		print "Error: tried to delete file that doesn't exist.\n"
		waitForUserInput()
		mainInterface()


# removes targetFolder. Will check if folder exists and if it doesn't it will redirect to main interface
def removeFolder(targetFolder):	
	if isFolder(targetFolder) == 1:
		subprocess.call(["rm", "-rf", targetFolder])
	else:
		print "Error: tried to delete folder that doesn't exist.\n"
		waitForUserInput()
		mainInterface()


# removes task from execute script
def removeCommandFromExec(name):
	global executeFileName
	setCronExecuteFileName("@" + getTaskSchedule(name))
	rmStr = genCronScriptCommand(name, getTaskType(name))
	findAndReplaceText(rmStr, "", executeFileName)
	reduceWhiteSpaceFile(3, executeFileName)
	

# returns task type of task
def getTaskType(name):
	global cronLogFileName
	fileObj = open(cronLogFileName, "r")
	rawStr = fileObj.read()
	fileObj.close()
	startIndex = rawStr.find(name) + len(name) + 17
	tempStr = rawStr[startIndex:len(rawStr)]
	endIndex = tempStr.find("Cron Task Created:")-1
	return tempStr[0:endIndex]
	

# returns schedule of task
def getTaskSchedule(name):
	global cronLogFileName
	fileObj = open(cronLogFileName, "r")
	rawStr = fileObj.read()
	fileObj.close()
	startIndex = rawStr.find(name) + len(name) + 17
	tempStr = rawStr[startIndex:len(rawStr)]
	startIndex = tempStr.find("Cron Task Scheduled: @") + len("Cron Task Scheduled: @")
	endIndex = tempStr.find("$$$$$$-Cron-Task-Ref-End-$$$$$$+")-1
	return tempStr[startIndex:endIndex]

#$$$$$+

# Cron Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# enables all cron scipts
def enableCronTasks():
	schedules = ['@reboot', '@yearly','@monthly','@weekly','@daily','@hourly']

	# makes sure user is root
	killIfNotRoot()

	for x in range(0, len(schedules)):
		setCronExecuteFileName(schedules[x])
		enableCronTasksForSchedule(schedules[x])
	
	print "Cron Tasks Enabled.\n"
	waitForUserInput()
	mainInterface()


# checks if execute script is in crontab. If it is, it tells the user. If not, it will add it.
def enableCronTasksForSchedule(schedule):
	global executeFileName
	rawTxt = getCronTaskStr()

	if rawTxt.count(schedule + " " + executeFileName) == 0:
		# creates temp file and puts crontab -l output in it. It then adds the cron task
		tempCronFile = open("0ddPGPTempCronFile", "w+")
		tempCronFile.write(rawTxt)
		tempCronFile.write("\n" + schedule + " " + executeFileName + "\n\n")	
		tempCronFile.close()
		reduceWhiteSpaceFile(3, "0ddPGPTempCronFile")

		# sets actual crontab to the temp file and then removes temp file
		os.system("crontab < 0ddPGPTempCronFile")
		os.remove("0ddPGPTempCronFile")

		
	else:
		print "Cron Tasks Already Enabled.\n"
		waitForUserInput()
		mainInterface()
	
# disables all cron scipts
def disableCronTasks():
	schedules = ['@reboot', '@yearly','@monthly','@weekly','@daily','@hourly']

	# makes sure user is root
	killIfNotRoot()

	for x in range(0, len(schedules)):
		setCronExecuteFileName(schedules[x])
		disableCronTasksForSchedule(schedules[x])
	
	print "Cron Tasks Disabled.\n"
	waitForUserInput()
	mainInterface()


# checks if execute script is in crontab. If it isn't, it tells the user. If it is, it will remove it.
def disableCronTasksForSchedule(schedule):
	global executeFileName
	rawTxt = getCronTaskStr()

	if rawTxt.count(schedule + " " + executeFileName) > 0:
		# creates temp file and puts crontab -l output in it
		tempCronFile = open("0ddPGPTempCronFile", "w+")
		tempCronFile.write(rawTxt)	
		tempCronFile.close()
		reduceWhiteSpaceFile(3, "0ddPGPTempCronFile")
		# finds the cron task and removes it from temp file making a version of crontab without those tasks active
		findAndReplaceText(schedule + " " + executeFileName, "", "0ddPGPTempCronFile")

		# sets actual crontab to the temp file and then removes temp file
		os.system("crontab < 0ddPGPTempCronFile")
		os.remove("0ddPGPTempCronFile")

		
	else:
		print "Cron Tasks Already Disabled.\n"
		waitForUserInput()
		mainInterface()


# gets current crontab file contents and outputs it to file
def getCronTaskStr():
	pipe = os.popen("crontab -l")
	return pipe.read()	
	

# finds the filepath of the crontab temp folder and returns it
def getCronTabFilePath():
	pipe = os.popen("ls /tmp")
	tmpContents = pipe.read()
	
	index = tmpContents.find("crontab.")
	truncatedStr = tmpContents[index:len(tmpContents)]
	lastIndex = truncatedStr.find("\n")

	tmpCronDir = truncatedStr[0:lastIndex]

	cronTabFilePathStr = "/tmp/" + tmpCronDir + "/crontab" 

	return cronTabFilePathStr


# generates name for config file used by latest cron task. Uses scheme 0ddPGP-CronTask-NAME-DATE-NUMFILECREATEDTODAY
def genCronConfigFileName():
	global cronConfigFolderName
	date = genDateString()
	
	personalName = raw_input("Enter Name For Task: ")
	print "\n"

	potentialName = "0ddPGP-CronTask-" + personalName + "-" + date + "-0"
	endNum = 0

	while isFile(cronConfigFolderName + "/" + potentialName) == 1:
		endNum += 1
		potentialName = "0ddPGP-CronTask-" + personalName + "-" + date + "-" + str(endNum)
	return potentialName


# generates new config file with unique name and specifed options
def genCronConfigFile(recipiant, fileName, folderName, shouldCleanUp, nameString):
	global cronConfigFolderName
	global backupName
	tempFile = open(backupName, "r")
	tempStr = tempFile.read()
	tempFile.close()
	newFile = open(cronConfigFolderName + "/" + nameString, "w+")
	newFile.write(tempStr)
	newFile.close()
	if shouldCleanUp == 1:
		findAndReplaceText("ShouldCleanUp:0", "ShouldCleanUp:1", cronConfigFolderName + "/" + nameString)	
	insertText("Recipiant:", recipiant, cronConfigFolderName + "/" + nameString)
	insertText("File:", fileName, cronConfigFolderName + "/" + nameString)
	insertText("Folder:", folderName, cronConfigFolderName + "/" + nameString)
	


# generates command in form of string to be used in cron task. Calls baseCronScript.sh to execute the base command with proper options and switch config files seemlessly
def genCronScriptCommand(taskName, taskType):
	global cronLogFileName
	global cronConfigFolderName
	global cronScriptFileName
	return "bash " + cronScriptFileName + " " + genCommandLineArg(taskType) + " " + cronConfigFolderName + "/" + taskName


# add reference of new cron task to log
def addCronTaskReferenceToLog(taskName, taskType, schedule):
	global cronLogFileName

	pipe = os.popen('date')
	date = pipe.read()
	logFile = open(cronLogFileName, "a")
	logFile.write("\n\n")
	logFile.write("$$$$$$-Cron-Task-Ref-Start-$$$$$$")
	logFile.write("\nCron Task Name: " + taskName)
	logFile.write("\nCron Task Type: " + taskType)
	logFile.write("\nCron Task Created: " + date)
	logFile.write("Cron Task Scheduled: " + schedule)
	logFile.write("\n$$$$$$-Cron-Task-Ref-End-$$$$$$+")
	logFile.write("\n\n")
	logFile.close()
	reduceWhiteSpaceFile(4, cronLogFileName)
	print "\nAdded reference to cron task log file.\n"


# removes cron task created by program previously
def removeCronTask(taskName):
	global cronLogFileName
	global cronConfigFolderName
	
	# sets str to contents of log file for parsing
	tempFileObj = open(cronLogFileName, "r")
	rawStr = tempFileObj.read()
	tempFileObj.close()

	# finds first index of string needed to be cut
	rawIndex = rawStr.find("$$$$$$-Cron-Task-Ref-Start-$$$$$$\nCron Task Name: " + taskName)
	
	# finds last index
	tempRawStr = rawStr[rawIndex:len(rawStr)]
	lastIndex = tempRawStr.find("+")

	# gens full string needed to be removed
	rmStr = tempRawStr[0:lastIndex+1]

	# removes command from execute script
	removeCommandFromExec(taskName)
	print "\nRemoved command from execute file"

	# removes string
	findAndReplaceText(rmStr, "\n", cronLogFileName)
	reduceWhiteSpaceFile(4, cronLogFileName)
	print "\nRemoved " + taskName + " From Log"

	# removes config file
	removeFile(cronConfigFolderName + "/" + taskName)
	print "\nRemoved config file for " + taskName



# prints list of all cron tasks the program has made
def listAllSetCronTasks():
	global cronLogFileName
	tempFileObj = open(cronLogFileName, "r")
	rawStr = tempFileObj.read()
	cronTasksList = []
	addStr = ""

	while rawStr.find("Cron Task Name: ") != -1:
		addStr = ""

		rawStr = rawStr[rawStr.find("Cron Task Name: ")+16:len(rawStr)]
		
		addStr = rawStr[0:rawStr.find("\n")]
		cronTasksList.append(addStr)
		rawStr = rawStr[rawStr.find("\n")+1: len(rawStr)]		
		
	return cronTasksList
	


# Procedure Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# encrypts single file. Used by -e
def encryptSingleProc():
	global currFile
	global currRecipiant	
	verifyShouldClean()
	getRecipiantFromUser()
	getFilepathFromUser()
	encryptFile(currFile, currRecipiant)

# decrypts single file. Used by -d
def decryptSingleProc():
	global currFile
	verifyShouldClean()
	getFilepathFromUser()
	decryptFile(currFile)

# compresses folder to .gz and then encrypts it. Used by -E
def encryptFolderProc():
	global currRecipiant
	global currFolder
	verifyShouldClean()
	getRecipiantFromUser()
	getFolderpathFromUser()
	encryptFolder(currFolder, currRecipiant)

# decrypts gz and then uncompressess. used by -D
def decryptFolderProc():
	global currFile	
	verifyShouldClean()
	getFilepathFromUser()
	decryptFolder(currFile)

# decrypts all files in folder that are encrypted. Not recursive. used by -C
def decryptFolderContentsProc():
	global currFolder
	verifyShouldClean()
	getFolderpathFromUser()
	getFileList(currFolder)
	sortFilesIntoLists()
	decryptAllInEncryptedList()	

# encrypts all files in folder that are not encrypted. Not recursive. Used by -c
def encryptFolderContentsProc():
	global currFolder
	verifyShouldClean()
	getRecipiantFromUser()
	getFolderpathFromUser()
	getFileList(currFolder)
	sortFilesIntoLists()
	encryptAllInEncryptedList()



# Misc Methods $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# exits program
def exitProgram():
	print "Exiting Program\n"
	sys.exit(2)


# checks if the program is executed as root. If it is, return 1. Otherwise, returns 0
def isRoot():
	pipe = os.popen("id -u")
	checker = pipe.read()

	if checker == "0\n":
		return 1
	else:
		return 0


# returns 1 if user exists in system and 0 otherwise
def isUser(user):
	checkStr = executeCommandAsUser(user, "whoami", 1)
	if checkStr == "":
		return 0
	else:
		return 1


# generates string of date in format yyyy-mm-dd
def genDateString():
	pipe = os.popen('date -I')
	rawDateStr = pipe.read()
	return rawDateStr[0:len(rawDateStr)-1]

# takes in task type for cron task and returns string in form of proper command line arg for calling the command
def genCommandLineArg(taskType):
	types = {'Encrypt Single File':"-e",'Decrypt Single File':"-d",'Encrypt Folder Using Tar':"-E",'Decrypt Encrypted Tar':"-D",'Encrypt Folder Contents':"-c",'Decrypt Folder Contents':"-C"}

	return types[taskType]


# sets execute file to proper script name
def setCronExecuteFileName(schedule):
	global executeFileName
	executeFileName = '/usr/lib/0ddPGP/cron/cron-scripts/ExecuteCronTasks.sh'
	executeFileName = replaceTextInStr(executeFileName, "Execute", schedule[1:len(schedule)] + "Execute")
	

# executes command as specified user
def executeCommandAsUser(user, command, shouldPipe):
	
	if shouldPipe == 0:
		os.system("su " + user + " -c " + "\"" + command + "\"")
	elif shouldPipe == 1:
		pipe = os.popen("su " + user + " -c " + "\"" + command + "\"")
		return pipe.read()
	else:
		print "Error: executeCommandAsUser shouldPipe arg set incorrectly"
		exitProgram()

	return "N/A"


# executes command as current user
def executeCommand(command, shouldPipe):
	
	if shouldPipe == 0:
		os.system(command)
	elif shouldPipe == 1:
		pipe = os.popen(command)
		return pipe.read()
	else:
		print "Error: executeCommand shouldPipe arg set incorrectly"
		exitProgram()

	return "N/A"


# gets all users in home dir 
def getUserList():

	# makes sure user is root
	killIfNotRoot()

	userList = []
	# get all users in home dir
	rawHomeDirStr = executeCommand("cat /etc/passwd | grep /home/ | grep /bin/", 1)
	rawHomeDirList = []
	# parse rawHomDirStr into list

	addStr = ""

	for x in range(0, len(rawHomeDirStr)):
		
		if rawHomeDirStr[x] == "\n":
			# on the off chance the grep comes up with a line that isn't a valid user, this fixes it I think.
			if isUser(addStr[0:addStr.find(":")]) == 1:		
				rawHomeDirList.append(addStr[0:addStr.find(":")])
			
			addStr = ""
		else:
			addStr += rawHomeDirStr[x]	

	# add root
	addStr = executeCommand("cat /etc/passwd | grep :x:0:0:", 1)
	rawHomeDirList.append(addStr[0:addStr.find(":")])
	
	return rawHomeDirList
	


# returns list of ls output when ls is ran in the dir user is currently at. Also has 2 binary options clarifying whether list should contain files/folders
def getLsList(files, folders):

	if (files != 0 and files != 1) or (folders != 0 and folders != 1):
		print "Error: invalid arg in getLsList"
		exitProgram()	

	lsList = []
	rawStr = executeCommand("ls", 1)
	index = 0
	
	while rawStr.count("\n") > 0:

		if (isFile(rawStr[0:rawStr.find("\n")]) == 1 and files == 1) or (isFolder(rawStr[0:rawStr.find("\n")]) == 1 and folders == 1):
			lsList.append(rawStr[0:rawStr.find("\n")])

		rawStr = rawStr[rawStr.find("\n")+1:len(rawStr)]

	return lsList



#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# options

def main(argv):

	try:
		opts, args = getopt.getopt(argv, "hedEDCcm")
	except getopt.GetoptError:
		print 'try python 0dd3yePGP.py -h for help\n'
		sys.exit(2)

	setConfigOptions()

	
	
	for opt, arg in opts:
		
		if opt in ('-h'):
			print 'usage: 0ddpgp <options>\n-h print options\n-e encrypt file\n-d decrypt file\n-E encrypt folder to .gz\n-D decrypt .gz to folder\n-C decrypt encrypted files in folder\n-c encrypt decrypted files in folder\n-m manual interface'
			sys.exit()
		elif opt in ('-e'):
			encryptSingleProc()
		elif opt in ('-d'):
			decryptSingleProc()
		elif opt in ('-E'):
			encryptFolderProc()
		elif opt in ('-D'):
			decryptFolderProc()
		elif opt in ('-C'):
			decryptFolderContentsProc()	
		elif opt in ('-c'):
			encryptFolderContentsProc()
		elif opt in ('-m'):
			print "Current user is " + currUser
			mainInterface()

if __name__ == "__main__":
	main(sys.argv[1:])

#!/bin/bash

# This script exists to be run by cron and will execute all set tasks created by program.



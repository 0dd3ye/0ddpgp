#!/bin/bash

# $1 is type, $2 is config file

# This script only exists to be used as a cron task. Unless you know what you are doing you should not run the script manually.

# copies contents of current config to personal config
cp /usr/lib/0ddPGP/0dd3yePGP-Config /usr/lib/0ddPGP/personalConfig


# copies contents of task config to actual config
cp $2 /usr/lib/0ddPGP/0dd3yePGP-Config

# executes program
0ddpgp $1

# copies contents of personal config back to original config
cp /usr/lib/0ddPGP/personalConfig /usr/lib/0ddPGP/0dd3yePGP-Config   

#  
